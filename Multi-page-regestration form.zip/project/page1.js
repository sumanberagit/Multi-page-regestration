function seterror (id,error)
{
element= document.getElementById(id);
element= document.getElementsByClassName('formerror')[0].innerHtml=error;


}

function validateForm()
{
    var returnval=true;
    var name=document.forms['myform']['fname'].value;
    if(name.length<5){
        seterror("name","Length is too short")
        returnval=false;
    }

    return returnval;

}
var form=document.getElementById('form')
form.addEventListener('button',function displaydata(event){
    event.preventDefault()


var name=document.getElementById('Finput').value
console.log(name)
var Lastname=document.getElementById('Linput').value
console.log(Lastname)
var email=document.getElementById('Einput').value
console.log(email)
var date=document.getElementById('dob').value
console.log(date)
var phone=document.getElementById('mobile').value
console.log(phone)
var baba=document.getElementById('baba').value
console.log(baba)
var ma=document.getElementById('ma').value
console.log(ma)
})
var button=document.getElementById('btn')
.addEventListener("click",displaydata);